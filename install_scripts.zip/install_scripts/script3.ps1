﻿#restart the computer
restart-computer