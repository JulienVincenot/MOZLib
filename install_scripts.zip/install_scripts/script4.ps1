﻿#this script should be lauched right after the restart
#set WSL default version 2
wsl --set-default-version 2

Read-Host -Prompt "wsl set to Ver.2 - Press Enter to exit"